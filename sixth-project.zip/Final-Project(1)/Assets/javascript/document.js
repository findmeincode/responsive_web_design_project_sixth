// $(document).redy(function(){
//     $('.owl-carousel').owlCarousel({
//         loop:true,
//         margin:10,
//         nav:true,
//         responsive:{
//             0:{
//                 items:1
//             },
//             600:{
//                 items:3
//             },
//             1000:{
//                 items:5
//             }
//         }
//     })
// });

// banner slider
$('.owl-carousel').owlCarousel({
    loop:true,
    responsiveClass:true,
    autoplay: false,
    speed: 2000,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:1,
            nav:false
        },
        1000:{
            items:1,
            nav:true,
            loop:true
        }
    }
});




// client section card slider
$(document).ready(function(){
    $('.center').slick({
        centerMode: true,
        centerPadding: '0px',
        slidesToShow: 3,
        dots: false,
        autoplay: false,
        autoplaySpeed:3000,
        speed: 1500,
        prevArrow: $('.prev'),
        nextArrow: $('.next'),

        responsive: [
        {
            breakpoint: 768,
            settings: {
            arrows: false,
            centerMode: true,
            centerPadding: '40px',
            slidesToShow: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
            arrows: false,
            centerMode: true,
            centerPadding: '40px',
            slidesToShow: 1
            }
        }
        ]
    });
});


// products section slider
$(document).ready(function() {
    $('.logo-carousel').slick({
      slidesToShow: 7,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 1000,
      arrows: false,
      dots: true,
      pauseOnHover: true,
      responsive: [{
        breakpoint: 768,
        settings: {
          slidesToShow: 4
        }
      }, {
        breakpoint: 520,
        settings: {
          slidesToShow: 2
        }
      }]
    });
  });